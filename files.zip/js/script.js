document.getElementById('login-form').addEventListener('submit', function(event) {
    const errorMessage = document.getElementById('error-message');
    errorMessage.innerText = ''; // Limpa a mensagem de erro

    // O formulário é enviado via POST para login.php
});